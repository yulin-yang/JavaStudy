package com.xuecheng;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XuechengPlusParentApplication {

    public static void main(String[] args) {
        SpringApplication.run(XuechengPlusParentApplication.class, args);
    }

}
