package com.xuecheng.media.model.dto;

import com.xuecheng.media.model.po.MediaFiles;
import lombok.Data;

@Data
public class UploadFileResultDto extends MediaFiles {
}
