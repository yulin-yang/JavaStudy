package com.xuecheng;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XuechengPlusGatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}
