package com.xuecheng;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class XuechengPlusContentApiApplicationTests {

    @Test
    void contextLoads() {
    }
}
