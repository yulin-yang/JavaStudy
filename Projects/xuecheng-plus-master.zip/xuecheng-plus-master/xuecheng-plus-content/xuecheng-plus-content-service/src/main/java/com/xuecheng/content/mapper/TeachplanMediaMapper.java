package com.xuecheng.content.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xuecheng.content.model.po.TeachplanMedia;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author cyborg2077
 */
public interface TeachplanMediaMapper extends BaseMapper<TeachplanMedia> {

}
