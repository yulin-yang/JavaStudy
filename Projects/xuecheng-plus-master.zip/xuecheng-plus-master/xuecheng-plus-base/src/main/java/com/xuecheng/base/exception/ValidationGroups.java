package com.xuecheng.base.exception;

/**
 * @description 校验分组
 */
public class ValidationGroups {
    public interface Insert{}

    public interface Update{}

    public interface Delete{}

}
