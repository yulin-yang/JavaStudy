package com.xuecheng.messagesdk.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xuecheng.messagesdk.model.po.MqMessageHistory;

/**
 * 服务类
 *
 */
public interface MqMessageHistoryService extends IService<MqMessageHistory> {

}
